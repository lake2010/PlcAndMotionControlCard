﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InControls.Common
{
    public enum WorkRegionEnum
    {
        UnDefine = 0,
        StoneMaterial = 1,
        Asphalt,
        Slag,
        Cold,
    }
}
